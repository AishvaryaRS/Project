﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BookMyStay.Data;
using BookMyStay.Models;
using System.Threading.Tasks;
using System.Linq;

namespace BookMyStay.Controllers
{
    public class HotelsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HotelsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Action to display all hotels
        public async Task<IActionResult> Index()
        {
            var hotels = await _context.Hotels.ToListAsync(); // Fetch hotels from the database
            return View(hotels);
        }

        // Action to add a new hotel (GET)
        public IActionResult Add()
        {
            return View();
        }

        // Action to add a new hotel (POST)
        [HttpPost]
        public async Task<IActionResult> Add(Hotel hotel)
        {
            if (ModelState.IsValid)
            {
                _context.Hotels.Add(hotel); // Add hotel to the context
                await _context.SaveChangesAsync(); // Save changes to the database
                return RedirectToAction("Index");
            }

            return View(hotel);
        }

        // Action to delete a hotel by ID
        public async Task<IActionResult> Delete(int id)
        {
            var hotel = await _context.Hotels.FindAsync(id); // Find hotel by ID
            if (hotel != null)
            {
                _context.Hotels.Remove(hotel); // Remove hotel from the context
                await _context.SaveChangesAsync(); // Save changes to the database
            }
            return RedirectToAction("Index");
        }
    }
}
