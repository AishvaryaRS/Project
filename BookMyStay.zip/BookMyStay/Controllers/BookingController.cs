﻿using Microsoft.AspNetCore.Mvc;
using BookMyStay.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore; // Make sure this is included
using System.Collections.Generic;
using System.Linq;
using BookMyStay.Data;

namespace BookMyStay.Controllers
{
    public class BookingController : Controller
    {
        private readonly ApplicationDbContext _context;

        public BookingController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Create()
        {
            var model = new BookingViewModel
            {
                HotelRooms = GetHotelRooms(), // Populate hotel rooms
                CheckInDate = DateTime.Today // Set default CheckInDate to today
            };
            return View(model);
        }

        [HttpPost]
        public IActionResult Book(BookingViewModel model)
        {
            // Assign default user ID (assumed to be 1)
            int defaultUserId = 1;

            if (ModelState.IsValid)
            {
                // Retrieve selected hotel room details
                var hotelRoom = _context.HotelRooms
                    .Include(r => r.Hotel) // Include hotel details
                    .FirstOrDefault(r => r.HotelRoomId == model.HotelRoomId);

                if (hotelRoom != null)
                {
                    // Create booking and set its properties
                    var booking = new BookingDetails
                    {
                        UserId = defaultUserId,
                        HotelRoomId = hotelRoom.HotelRoomId,
                        CheckInDate = model.CheckInDate,
                        CheckOutDate = model.CheckOutDate,
                        Cost = hotelRoom.Price, // Assuming Price is a property of HotelRoom
                        HotelName = hotelRoom.Hotel.HotelName, // Assuming navigation property
                        RoomType = hotelRoom.RoomType
                    };

                    // Add booking to the context and save changes
                    _context.Bookings.Add(booking);
                    _context.SaveChanges();

                    // Set a success message
                    TempData["SuccessMessage"] = "Booking created successfully!";
                    return RedirectToAction("Index", "Home"); // Redirect to the home page or booking list
                }

                ModelState.AddModelError("", "Selected room not found.");
            }
            else
            {
                // If model state is not valid, log the errors
                var errors = ModelState.Values.SelectMany(v => v.Errors);
                foreach (var error in errors)
                {
                    ModelState.AddModelError("", error.ErrorMessage);
                }
            }

            // If we get here, something went wrong; re-populate hotel rooms
            model.HotelRooms = GetHotelRooms();
            return View(model);
        }

        private List<SelectListItem> GetHotelRooms()
        {
            // Retrieve available hotel rooms and create SelectListItems
            return _context.HotelRooms.Select(room => new SelectListItem
            {
                Value = room.HotelRoomId.ToString(),
                Text = $"{room.RoomType} - {room.Price:C}"
            }).ToList();
        }
    }
}
