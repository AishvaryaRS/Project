﻿using Microsoft.AspNetCore.Mvc; // allowing you to use its classes and methods,including Controller, which is the base class for MVC controllers
using BookMyStay.Data; // Include your DbContext
using System.Threading.Tasks; // Include for async methods
using Microsoft.EntityFrameworkCore; // extensions of db Include for DbSet<T>

namespace BookMyStay.Controllers.Admin
{
    [Area("Admin")] // separate routing and views specific to admin functionalities.
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context; // Use your actual DbContext name

        // Constructor to inject the DbContext
        public AdminController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Admin/Hotels
        public async Task<IActionResult> Hotels()
        {
            var hotels = await _context.Hotels.ToListAsync(); // Fetch hotels from the database
            return View(hotels); // Pass the hotel list to the view
        }

        // Other admin actions like Create, Edit, Delete can be added here
    }
}
