﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using BookMyStay.Models; // Ensure this matches your project namespace

namespace BookMyStay.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<User> _userManager; // Inject UserManager for user operations
        private readonly SignInManager<User> _signInManager; // Inject SignInManager for sign-in operations

        // Constructor to inject UserManager and SignInManager
        public AccountController(UserManager<User> userManager, SignInManager<User> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }

        // GET: /Account/Register
        [HttpGet]
        public IActionResult Register()
        {
            return View(); // Return the Register view
        }

        // POST: /Account/Register
        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid) // Check if the model is valid
            {
                var user = new User // Create a new user instance
                {
                    UserName = model.Username,
                    Email = model.Email
                };

                var result = await _userManager.CreateAsync(user, model.Password); // Create user with password
                if (result.Succeeded) // If user creation is successful
                {
                    await _signInManager.SignInAsync(user, isPersistent: false); // Sign in the user
                    return RedirectToAction("Index", "Home"); // Redirect to home page
                }

                // Add errors to model state if creation fails
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }
            }

            return View(model); // Return to the Register view with the model to display validation errors
        }

        // GET: /Account/Login
        [HttpGet]
        public IActionResult Login()
        {
            return View(); // Return the Login view
        }

        // POST: /Account/Login
        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid) // Check if the model is valid
            {
                var user = await _userManager.FindByNameAsync(model.Username); // Find user by username
                if (user != null) // If user is found
                {
                    var result = await _signInManager.PasswordSignInAsync(user, model.Password, isPersistent: false, lockoutOnFailure: false); // Attempt sign-in
                    if (result.Succeeded) // If sign-in is successful
                    {
                        if (model.UserRole == "Admin") // Check if the role is Admin
                        {
                            return RedirectToAction("Index", "Admin"); // Redirect to Admin dashboard
                        }
                        return RedirectToAction("Index", "User"); // Redirect to User dashboard
                    }
                }

                ModelState.AddModelError(string.Empty, "Invalid login attempt."); // Add error for invalid attempt
            }

            return View(model); // Return to the Login view with the model to display validation errors
        }
    }
}
