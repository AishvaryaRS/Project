﻿namespace BookMyStay.Models
{
    public class Class
    {
    }
}
