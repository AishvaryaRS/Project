﻿using System.ComponentModel.DataAnnotations;

namespace BookMyStay.Models
{
    public class HotelRoom
    {
        [Key]
        public int HotelRoomId { get; set; }

        [Required]
        public required string RoomType { get; set; }

        [Required]
        public decimal Price { get; set; } // Assuming Price is a required field

        public int HotelId { get; set; } // Foreign key
        public Hotel Hotel { get; set; } = null!; // Navigation property
    }
}
