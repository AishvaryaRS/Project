﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace BookMyStay.Models
{
    public class Hotel
    {
        [Key]
        public int HotelId { get; set; }

        [Required]
        public required string HotelName { get; set; }

        public string? Address1 { get; set; }
        public string? Address2 { get; set; }
        public string? Address3 { get; set; }

        [Required]
        public required string City { get; set; }

        [Required]
        public required string Pincode { get; set; }

        // Navigation property for related HotelRooms
        public List<HotelRoom> HotelRooms { get; set; } = new List<HotelRoom>();
    }
}
