﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;

namespace BookMyStay.Models
{
    public class BookingViewModel
    {
        public int UserId { get; set; }
        public int HotelRoomId { get; set; }
        public DateTime CheckInDate { get; set; }
        public DateTime CheckOutDate { get; set; }

        // Initialize the property in the constructor
        public List<SelectListItem> HotelRooms { get; set; } = new List<SelectListItem>();

        // Optional: You can also create a constructor if needed
        public BookingViewModel()
        {
            HotelRooms = new List<SelectListItem>();
        }
    }
}
