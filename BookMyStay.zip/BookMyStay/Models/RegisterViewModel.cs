﻿using System.ComponentModel.DataAnnotations;

namespace BookMyStay.Models // Ensure this matches your project namespace
{
    public class RegisterViewModel
    {
        [Required(ErrorMessage = "Username is required.")]
        public required string Username { get; set; } = string.Empty; // Initialized to avoid null warning

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Invalid email address.")]
        public required string Email { get; set; } = string.Empty; // Initialized to avoid null warning

        [Required(ErrorMessage = "Password is required.")]
        [DataType(DataType.Password)]
        public required string Password { get; set; } = string.Empty; // Initialized to avoid null warning

        [Required(ErrorMessage = "Please confirm your password.")]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public required string ConfirmPassword { get; set; } = string.Empty; // Initialized to avoid null warning

        [Required(ErrorMessage = "User role is required.")]
        public required string UserRole { get; set; } = string.Empty; // Initialized to avoid null warning
    }
}
