﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using BookMyStay.Models;

namespace BookMyStay.Data
{
    public class ApplicationDbContext : IdentityDbContext<User>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        // DbSets for your models
        public DbSet<BookingDetails> Bookings { get; set; } // This should be defined
        public DbSet<HotelRoom> HotelRooms { get; set; }
        public DbSet<Hotel> Hotels { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder); // Call the base method

            // Configure decimal properties for precision and scale
            modelBuilder.Entity<BookingDetails>()
                .Property(b => b.Cost)
                .HasColumnType("decimal(18, 2)");

            modelBuilder.Entity<HotelRoom>()
                .Property(h => h.Price)
                .HasColumnType("decimal(18, 2)");
        }
    }
}
