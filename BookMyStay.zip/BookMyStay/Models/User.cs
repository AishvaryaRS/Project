﻿using Microsoft.AspNetCore.Identity; // Add this using directive
using System.ComponentModel.DataAnnotations;

namespace BookMyStay.Models
{
    public class User : IdentityUser  // Inherit from IdentityUser
    {
        [Key]
        public int UserId { get; set; }  // Keep this if you need a custom UserId

        // Remove the UserName property since it's already included in IdentityUser
        // You can add custom properties if needed
    }
}

