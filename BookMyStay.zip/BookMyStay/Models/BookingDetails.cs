﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

public class BookingDetails
{
    [Key]
    public int BookingId { get; set; }

    [Required(ErrorMessage = "Username is required")]
    public string Username { get; set; } = string.Empty;

    public int HotelRoomId { get; set; }

    [Required(ErrorMessage = "Check-in date is required")]
    public DateTime CheckInDate { get; set; }

    [Required(ErrorMessage = "Check-out date is required")]
    public DateTime CheckOutDate { get; set; }

    [Column(TypeName = "decimal(18, 2)")]
    [Required(ErrorMessage = "Cost is required")]
    public decimal Cost { get; set; }

    [Required(ErrorMessage = "Hotel name is required")]
    public string HotelName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Room type is required")]
    public string RoomType { get; set; } = string.Empty;

    public int UserId { get; set; } // Ensure this is of type int

    // Navigation properties (optional)
    // public virtual HotelRoom HotelRoom { get; set; }
    // public virtual User User { get; set; }
}
