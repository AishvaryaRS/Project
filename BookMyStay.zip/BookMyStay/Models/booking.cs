﻿using BookMyStay.Models;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

public class BookingModel
{
    [Key]
    public int BookingId { get; set; } // Primary key for the booking

    [Required]
    public int UserId { get; set; } // User ID for the booking

    [Required]
    public int HotelRoomId { get; set; } // ID of the hotel room

    [Required]
    [DataType(DataType.Date)]
    public DateTime CheckInDate { get; set; } // Check-in date

    [Required]
    [DataType(DataType.Date)]
    public DateTime CheckOutDate { get; set; } // Check-out date

    [Required]
    [Column(TypeName = "decimal(18,2)")]
    public decimal Cost { get; set; } // Cost of the booking

    [Required]
    public string HotelName { get; set; } = string.Empty; // Name of the hotel

    [Required]
    public string RoomType { get; set; } = string.Empty; // Type of room

    // Navigation properties
    [ForeignKey("UserId")]
    public virtual User User { get; set; } = null!; // Navigation property for User

    [ForeignKey("HotelRoomId")]
    public virtual HotelRoom HotelRoom { get; set; } = null!; // Navigation property for HotelRoom
}
